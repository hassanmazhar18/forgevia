# Put Forgevia Online — FREE — Every Click Explained

Total time: about 20 minutes. Total cost: **$0**. No credit card.
Host: **Koyeb** (free Hobby plan — always on, never sleeps, free HTTPS, free custom domains).
Backup: **GitHub** (free) so your users' data is never lost.

You need: a browser, your email, and **`forgevia-upload.zip`** from this workspace (click it → Download to your computer, then right-click → Extract All).

At the end your website is live at: **https://forgevia-YOURNAME.koyeb.app**

---

# PART 1 — Create a free GitHub account (3 min)

1. Go to **https://github.com/signup**
2. Enter **email** → **Continue** → create **password** → **Continue**
3. Choose a **username** (e.g. `hassan2255`) — write it down → **Continue**
4. Solve the puzzle → **Create account** → type the code GitHub emailed you
5. If it asks questions, click **Skip**. ✅

# PART 2 — Put the Forgevia code on GitHub (4 min)

1. Go to **https://github.com/new**
2. **Repository name**: `forgevia` → choose **Public** (or Private — both work) → **Create repository**
3. On the next page click the link **"uploading an existing file"** (in the "Quick setup" box).
4. Open the extracted `forgevia` folder on your computer, press **Ctrl+A** to select everything inside it, and **drag** it into the browser upload box.
   ⚠️ Drag the *contents* of the folder, not the folder itself. `Dockerfile` and `server.py` must appear at the top level.
5. Wait for the upload bars to finish → click green **Commit changes**. ✅

# PART 3 — Create the backup "safe box" (2 min)

1. Go to **https://github.com/new** again
2. **Repository name**: `forgevia-data` → choose **Private** → **Create repository**. ✅
   (Forgevia will save all users, sites and the database here every 10 minutes.)

# PART 4 — Get a GitHub key (token) (2 min)

1. Go to **https://github.com/settings/tokens/new**
2. **Note**: `forgevia` · **Expiration**: **No expiration** · under *Select scopes* tick **☑ repo**
3. Scroll down → **Generate token**
4. Copy the code starting with **`ghp_`** into Notepad. ⚠️ Shown only once (if lost, repeat this part). ✅

# PART 5 — Create a free Koyeb account (2 min)

1. Go to **https://app.koyeb.com/auth/signup**
2. Click **Sign up with GitHub** → **Authorize Koyeb** (easiest — no new password).
3. Complete the short profile form. Choose the **Hobby (Free)** plan if asked. ✅
   (If Koyeb ever asks for a card: it says some regions require it for identity check only, with no charge. If that happens to you, tell me — I'll switch you to the fallback host, Back4app, which never asks.)

# PART 6 — Deploy Forgevia (5 min)

1. In Koyeb click **Create Service** (or **Create Web Service**).
2. Deployment method: **GitHub**.
3. If asked, click **Install GitHub App** / **Configure** → select your `forgevia` repository → Save.
4. Choose repository **forgevia**, branch **main**.
5. **Builder**: choose **Dockerfile** (Koyeb usually detects it automatically).
6. **Instance**: choose **Free** (Eco / Hobby, 512 MB).
7. **Region**: choose the nearest offered (Frankfurt or Singapore).
8. **Exposed port**: make sure it says **8000** (change it if it shows 8080).
9. Scroll to **Environment variables** → click **Add variable** three times:
   | Name | Value |
   |---|---|
   | `FV_BACKUP_REPO` | `YOUR-GITHUB-USERNAME/forgevia-data` (e.g. `hassan2255/forgevia-data`) |
   | `FV_BACKUP_TOKEN` | the `ghp_…` key from Part 4 (choose type **Secret** if offered) |
   | `PORT` | `8000` |
10. **Service name**: `forgevia`
11. Click **Deploy**. Watch the build log — it takes 3–5 minutes. When status turns **Healthy**, you're live. 🎉
12. Your address is shown at the top of the service page, like **https://forgevia-hassan2255.koyeb.app**.

# PART 7 — Sign in and take ownership (1 min)

1. Open your address → **Start building** → **Sign in**: `has2255000@gmail.com` + your password.
2. **Account** → change your password to a new strong one.
3. Test: New project → Publish → open the live link. Real internet, real users. ✅
4. In Koyeb → your service → **Logs**: you should see `persist: enabled → …/forgevia-data every 10 min`. That confirms backups are on.

# PART 8 — Free nicer address (optional, 5 min)

Koyeb gives **5 free custom domains**. Free domain options:
- **DuckDNS** (https://www.duckdns.org) → sign in with Google → type `forgevia` → **add domain** → you get `forgevia.duckdns.org`.
- Or a free `.eu.org` / `.pp.ua` domain.
Then Koyeb → service → **Settings → Domains → Add domain** → enter it → copy the CNAME Koyeb shows → paste it into DuckDNS/your provider. Tell me and I'll help finish it.

# PART 9 — Tell people (free)

- WhatsApp groups, Facebook groups, LinkedIn, Reddit (r/webdev, r/SideProject), X/Twitter.
- **Product Hunt** (free launch): https://www.producthunt.com/posts/new
- **Google Search Console**: https://search.google.com/search-console → Add property → URL prefix → your address → verify → submit sitemap `sitemap.xml`.

---

# Updating Forgevia later
When I improve the code I'll give you a new zip → GitHub `forgevia` repo → **Add file → Upload files** → Commit. Koyeb redeploys automatically. Your data stays safe in `forgevia-data`.

# If something goes wrong
| What you see | What to do |
|---|---|
| Build failed | Koyeb → Build logs → copy the last 20 lines → paste to me. |
| "Unhealthy" / port error | Check Exposed port = 8000 and `PORT` variable = 8000. |
| Logs: `persist: not configured` | Variables in Part 6 step 9 missing or misspelled — names must match exactly. |
| Logs: `persist: backup failed 404` | `FV_BACKUP_REPO` must be exactly `username/forgevia-data`. |
| Logs: `persist: backup failed 401` | Token wrong/expired → repeat Part 4, update the variable, redeploy. |
| Koyeb asks for a credit card | Stop and tell me — I'll give you the Back4app steps instead. |
